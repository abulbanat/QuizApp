package uz.pdp.university

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
