class FileInputStream {
    FileInputStream(def p) {
    }
}
