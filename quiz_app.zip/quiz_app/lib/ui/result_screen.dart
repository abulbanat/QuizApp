import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'package:quiz_app/models/subject_model.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../main.dart';

class ResultsScreen extends StatefulWidget {
  const ResultsScreen({super.key, required this.subject, required this.selectedAnswers});

  final SubjectModel subject;
  final List<int> selectedAnswers;

  @override
  State<ResultsScreen> createState() => _ResultsScreenState();
}

class _ResultsScreenState extends State<ResultsScreen> {



  setResult()async{

    int? subjectResult = prefs.getInt(widget.subject.resultKey);

    if(subjectResult!=null){
      int currentResult = calculateTrueAnswersCount();
      if(subjectResult<currentResult){
        prefs.setInt(widget.subject.resultKey, currentResult);
      }
    }
  }

  @override
  void initState() {
    setResult();
    super.initState();
  }

  int calculateTrueAnswersCount(){
    int trueCount = 0;

    for(int i=0; i<widget.subject.questions.length; i++){
      if(widget.subject.questions[i].trueAnswer==widget.selectedAnswers[i]){
        trueCount++;
      }
    }
    return trueCount;
  }

  @override
  Widget build(BuildContext context) {



    double percentage = (100*calculateTrueAnswersCount())/widget.selectedAnswers.length;

    return Scaffold(
      backgroundColor: Color(0xFF393E46),

      appBar: AppBar(

        title:
        Text("RESULTS", style:
          TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w400,
            color: Colors.white,
            fontFamily: 'MochiyPopOne',
          ),),
      ),
      body:

    Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        if(percentage>=0&&percentage<=60)

        Lottie.asset('assets/lottie/bad_score.json'),
        if(percentage>60&&percentage<=86)

        Lottie.asset('assets/lottie/good_score.json'),

        if(percentage>86&&percentage<=100)
        Lottie.asset('assets/lottie/great_score.json'),


      Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("YOUR SCORE: ${calculateTrueAnswersCount()} / ${widget.subject.questions.length}",
              style:
              const TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.w400,
                color: Colors.white,
                fontFamily: 'MochiyPopOne',
              ),
            ),
          ],
        ),
      ),

    ],)

    );
  }
}
