import 'package:flutter/material.dart';
import 'package:quiz_app/data/repository.dart';
import 'package:quiz_app/models/widgets/subject_item_view.dart';
import 'package:quiz_app/ui/quiz_screen.dart';
class SubjectsSreen extends StatefulWidget {
  const SubjectsSreen({super.key});

  @override
  State<SubjectsSreen> createState() => _SubjectsSreenState();
}

class _SubjectsSreenState extends State<SubjectsSreen> {
  @override
  Widget build(BuildContext context) {
    return  Scaffold(

      backgroundColor: Color(0xFF393E46),
     

      body: Column(
         children:[

           const SizedBox(height: 60),
           Text("WELCOME TO \n QUIZ TIME",
           textAlign: TextAlign.center,
           style: TextStyle(
             fontFamily: 'MochiyPopOne',
             fontSize: 32,
             fontWeight: FontWeight.w400,
             color: Color(0xFFFFFFFF),
           ) ),
           const SizedBox(height: 33),
           Text("SELECT THE SUBJECT",
               textAlign: TextAlign.center,
               style: TextStyle(
                 fontFamily: 'MochiyPopOne',
                 fontSize: 16,
                 fontWeight: FontWeight.w400,
                 color: Color(0xFFFFFFFF),
               ) ),

            Column(
              children: [
                Row(
                  children: [
                    SubjectItemView(subject: AppRepository.subjects[0],
                        onTap: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context){
                        return QuizScreen( subjectModel: AppRepository.subjects[0],);
                      }));
                        }),
                    SubjectItemView(subject: AppRepository.subjects[1],
                        onTap: (){
                          Navigator.push(context, MaterialPageRoute(builder: (context){
                            return QuizScreen( subjectModel: AppRepository.subjects[1],);
                          }));
                        }),],
                ),
                Row(
                  children: [
                    SubjectItemView(subject: AppRepository.subjects[2],
                        onTap: (){
                          Navigator.push(context, MaterialPageRoute(builder: (context){
                            return QuizScreen( subjectModel: AppRepository.subjects[2],);
                          }));
                        }),
                    SubjectItemView(subject: AppRepository.subjects[3],
                        onTap: (){
                          Navigator.push(context, MaterialPageRoute(builder: (context){
                            return QuizScreen( subjectModel: AppRepository.subjects[3],);
                          }));
                        }),
                   ],
                ),


              ],

            ),





        ],

      ),
    );
  }
}
