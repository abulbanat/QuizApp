import 'package:flutter/material.dart';

class AppColors{
  static const Color bgcolor = Color(0xFFE2F3F3);
  static const Color appbarcolor = Color(0xFF1E1E1E);

}