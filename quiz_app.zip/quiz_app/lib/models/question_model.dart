import 'package:quiz_app/models/question_level.dart';

class QuestionModel{
  QuestionModel({
    required this.trueAnswer,
    required this.answer4,
    required this.answer3,
    required this.answer2,
    required this.answer1,
    required this.QuestionText,
    this.id,
    this.questionLevel= QuestionLevel.easy,


  });

  String? id;
  final String QuestionText;
  final String answer1;
  final String answer2;
  final String answer3;
  final String answer4;
  final int trueAnswer;
  final QuestionLevel questionLevel;


}