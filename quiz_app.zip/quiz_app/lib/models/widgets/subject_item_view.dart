import 'package:flutter/material.dart';
import 'package:quiz_app/models/subject_model.dart';

class SubjectItemView extends StatelessWidget {
  const SubjectItemView({super.key, required this.subject, required this.onTap});

  final SubjectModel subject;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child:  Container(
        width: 156,
        height: 200,
        margin: const EdgeInsets.all(19),
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(15),
            color: Color(0xFF222831)
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Image.asset(
                  subject.iconPath,
                    width: 140,),
                  const SizedBox(height: 5),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(subject.subjectName,style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'MochiyPopOne',
                        color: Colors.white,
                      ),
                      ),
                      const SizedBox(height: 3),
                      Text(" ${subject.questions.length} QUESTIONS ", style: TextStyle(
                        fontSize: 11,
                        fontFamily: 'MochiyPopOne',
                        fontWeight: FontWeight.w600,
                        color: Color(0xFF00ADB5),
                      ),
                      ),],
                  )

                ],),
            ),


          ],
        ),
      ),
    );
  }
}
