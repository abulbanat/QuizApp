enum QuestionLevel{
  easy,
  medium,
  hard,
}