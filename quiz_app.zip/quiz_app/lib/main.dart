import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:quiz_app/ui/introduction_screen.dart';
import 'package:quiz_app/utils/app_colors.dart';
import 'package:shared_preferences/shared_preferences.dart';


late SharedPreferences prefs;
void main()async{
  prefs = await SharedPreferences.getInstance();
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: IntroductionScreen(),
    theme: ThemeData(
      scaffoldBackgroundColor: AppColors.bgcolor,
      appBarTheme: AppBarTheme(
        systemOverlayStyle: SystemUiOverlayStyle(
          statusBarColor: AppColors.appbarcolor,
        ),
        backgroundColor: AppColors.appbarcolor,
        elevation: 0,
      )
    ),
  ));
}