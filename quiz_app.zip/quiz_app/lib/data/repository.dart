import 'package:flutter/material.dart';
import 'package:quiz_app/models/question_model.dart';

import '../models/subject_model.dart';

class AppRepository{

static List<SubjectModel> subjects = [
  SubjectModel(
      resultKey: 'math-result',
      subjectName: "Math",
      iconPath: "assets/images/math.png",
      questions: [
        QuestionModel(
            trueAnswer: 2,
            answer1: "12",
            answer2: "13",
            answer3: "15",
            answer4: "18",
            QuestionText: "8 + 5 = ?"
        ),
        QuestionModel(
            trueAnswer: 4,
            answer1: "15",
            answer2: "12",
            answer3: "9",
            answer4: "13",
            QuestionText: "20 - 7 = ?"
        ),
        QuestionModel(
            trueAnswer: 4,
            answer1: "48",
            answer2: "63",
            answer3: "36",
            answer4: "54",
            QuestionText: "6 x 9 = ?"
        ),
        QuestionModel(
            trueAnswer: 3,
            answer1: "8",
            answer2: "10",
            answer3: "9",
            answer4: "11",
            QuestionText: "45 ÷ 5 = ?"
        ),
        QuestionModel(
            trueAnswer: 2,
            answer1: "6",
            answer2: "9",
            answer3: "7",
            answer4: "16",
            QuestionText: "3² = ?"
        ),
        QuestionModel(
            trueAnswer: 4,
            answer1: "18",
            answer2: "22",
            answer3: "26",
            answer4: "24",
            QuestionText: "16 + 8 = ?"
        ),
        QuestionModel(
            trueAnswer: 2,
            answer1: "10",
            answer2: "8",
            answer3: "12",
            answer4: "9",
            QuestionText: "14 - 6 = ?"
        ),
        QuestionModel(
            trueAnswer: 4,
            answer1: "42",
            answer2: "56",
            answer3: "36",
            answer4: "49",
            QuestionText: "7 x 7 = ?"
        ),
        QuestionModel(
            trueAnswer: 3,
            answer1: "6",
            answer2: "8",
            answer3: "7",
            answer4: "9",
            QuestionText: "28 ÷ 4 = ?"
        ),
        QuestionModel(
            trueAnswer: 3,
            answer1: "64",
            answer2: "72",
            answer3: "81",
            answer4: "49",
            QuestionText: "9² = ?"
        ),
        QuestionModel(
            trueAnswer: 2,
            answer1: "20",
            answer2: "25",
            answer3: "22",
            answer4: "18",
            QuestionText: "15 + 10 = ?"
        ),
        QuestionModel(
            trueAnswer: 1,
            answer1: "24",
            answer2: "32",
            answer3: "20",
            answer4: "16",
            QuestionText: "36 - 12 = ?"
        ),
        QuestionModel(
            trueAnswer: 2,
            answer1: "18",
            answer2: "24",
            answer3: "28",
            answer4: "30",
            QuestionText: "4 x 6 = ?"
        ),
        QuestionModel(
            trueAnswer: 3,
            answer1: "8",
            answer2: "10",
            answer3: "9",
            answer4: "7",
            QuestionText: "63 ÷ 7 = ?"
        ),
        QuestionModel(
            trueAnswer: 3,
            answer1: "100",
            answer2: "112",
            answer3: "121",
            answer4: "125",
            QuestionText: "11² = ?"
        ),
      ],
      color: Colors.teal),
  SubjectModel(
    resultKey: 'english-result',
      subjectName: "English",
      iconPath: "assets/images/english.png",
      questions: [
        QuestionModel(
            trueAnswer: 3,
            answer1: "Biology",
            answer2: "Physics",
            answer3: "Chemistry",
            answer4: "Mathematics",
            QuestionText: "Which subject deals with the study of elements and compounds?"
        ),
        QuestionModel(
            trueAnswer: 2,
            answer1: "Summer",
            answer2: "Winter",
            answer3: "Spring",
            answer4: "Autumn",
            QuestionText: "Which season comes after autumn?"
        ),
        QuestionModel(
            trueAnswer: 1,
            answer1: "Elephant",
            answer2: "Giraffe",
            answer3: "Kangaroo",
            answer4: "Penguin",
            QuestionText: "Which animal is known for its long trunk?"
        ),
            QuestionModel(
                trueAnswer: 4,
                answer1: "Apple",
                answer2: "Banana",
                answer3: "Orange",
                answer4: "Grapes",
                QuestionText: "Which fruit is typically associated with the color purple?"
            ),
            QuestionModel(
                trueAnswer: 3,
                answer1: "Car",
                answer2: "Bicycle",
                answer3: "Airplane",
                answer4: "Boat",
                QuestionText: "What mode of transportation can fly in the sky?"
            ),
            QuestionModel(
                trueAnswer: 2,
                answer1: "Library",
                answer2: "Museum",
                answer3: "Cinema",
                answer4: "Park",
                QuestionText: "Where can you typically find art and historical artifacts on display?"
            ),
            QuestionModel(
                trueAnswer: 4,
                answer1: "Swim",
                answer2: "Fly",
                answer3: "Crawl",
                answer4: "Walk",
                QuestionText: "What can humans do that fish cannot?"
            ),
            QuestionModel(
                trueAnswer: 1,
                answer1: "Ocean",
                answer2: "Lake",
                answer3: "River",
                answer4: "Pond",
                QuestionText: "Which body of water is the largest on Earth?"
            ),
            QuestionModel(
                trueAnswer: 3,
                answer1: "Circle",
                answer2: "Triangle",
                answer3: "Square",
                answer4: "Oval",
                QuestionText: "Which shape has four equal sides and four right angles?"
            ),
            QuestionModel(
                trueAnswer: 4,
                answer1: "Red",
                answer2: "Blue",
                answer3: "Green",
                answer4: "Yellow",
                QuestionText: "What color do you get when you mix red and blue?"
            ),
            QuestionModel(
                trueAnswer: 2,
                answer1: "Spoon",
                answer2: "Fork",
                answer3: "Knife",
                answer4: "Chopsticks",
                QuestionText: "What utensil is typically used for eating pasta?"
            ),
            QuestionModel(
                trueAnswer: 3,
                answer1: "Dog",
                answer2: "Cat",
                answer3: "Bird",
                answer4: "Fish",
                QuestionText: "Which pet can often mimic human speech?"
            ),
            QuestionModel(
                trueAnswer: 1,
                answer1: "Book",
                answer2: "Magazine",
                answer3: "Newspaper",
                answer4: "Comic",
                QuestionText: "What is a common source of written stories and information?"
            ),
            QuestionModel(
                trueAnswer: 4,
                answer1: "Earth",
                answer2: "Moon",
                answer3: "Mars",
                answer4: "Sun",
                QuestionText: "What is the center of our solar system?"
            ),
            QuestionModel(
                trueAnswer: 2,
                answer1: "Pencil",
                answer2: "Pen",
                answer3: "Crayon",
                answer4: "Marker",
                QuestionText: "Which writing instrument typically uses ink?"
            ),
      ],
      color: Colors.teal),
  SubjectModel(
      resultKey: 'physics-result',
      subjectName: "Physics",
      iconPath: "assets/images/physics.png",
      questions: [
        QuestionModel(
            trueAnswer: 2,
            answer1: "Volt",
            answer2: "Ampere",
            answer3: "Watt",
            answer4: "Ohm",
            QuestionText: "What is the SI unit of electric current?"
        ),
        QuestionModel(
            trueAnswer: 1,
            answer1: "Newton's First Law",
            answer2: "Newton's Second Law",
            answer3: "Newton's Third Law",
            answer4: "Newton's Law of Universal Gravitation",
            QuestionText: "Which law of motion states that an object at rest tends to stay at rest, and an object in motion tends to stay in motion unless acted upon by an external force?"
        ),
        QuestionModel(
            trueAnswer: 4,
            answer1: "Newton",
            answer2: "Joule",
            answer3: "Pascal",
            answer4: "Newton",
            QuestionText: "What is the SI unit of force?"
        ),
        QuestionModel(
            trueAnswer: 3,
            answer1: "Kinetic Energy",
            answer2: "Potential Energy",
            answer3: "Thermal Energy",
            answer4: "Electrical Energy",
            QuestionText: "Which type of energy is associated with the motion of atoms and molecules in a substance?"
        ),
        QuestionModel(
            trueAnswer: 2,
            answer1: "Law of Conservation of Momentum",
            answer2: "Law of Conservation of Energy",
            answer3: "Law of Inertia",
            answer4: "Law of Universal Gravitation",
            QuestionText: "What is the law that states that the total energy of an isolated system remains constant over time?"
        ),
        QuestionModel(
            trueAnswer: 3,
            answer1: "Ohm",
            answer2: "Joule",
            answer3: "Coulomb",
            answer4: "Watt",
            QuestionText: "What is the SI unit of electric charge?"
        ),
        QuestionModel(
            trueAnswer: 1,
            answer1: "Proton",
            answer2: "Neutron",
            answer3: "Electron",
            answer4: "Photon",
            QuestionText: "Which fundamental particle has a positive electric charge?"
        ),
        QuestionModel(
            trueAnswer: 4,
            answer1: "Acceleration",
            answer2: "Velocity",
            answer3: "Force",
            answer4: "Inertia",
            QuestionText: "What is the term for the resistance of an object to a change in its state of motion?"
        ),
        QuestionModel(
            trueAnswer: 4,
            answer1: "Radio Waves",
            answer2: "Microwaves",
            answer3: "Infrared",
            answer4: "Gamma Rays",
            QuestionText: "Which type of electromagnetic radiation has the shortest wavelength?"
        ),
        QuestionModel(
            trueAnswer: 3,
            answer1: "Watt-Hour",
            answer2: "Joule",
            answer3: "Watt",
            answer4: "Volt-Ampere",
            QuestionText: "What is the SI unit of power?"
        ),
        QuestionModel(
            trueAnswer: 2,
            answer1: "Reflection",
            answer2: "Refraction",
            answer3: "Diffraction",
            answer4: "Interference",
            QuestionText: "What is the phenomenon where a wave changes direction as it passes from one medium to another?"
        ),
        QuestionModel(
            trueAnswer: 1,
            answer1: "Friction",
            answer2: "Tension",
            answer3: "Gravity",
            answer4: "Buoyancy",
            QuestionText: "What is the term for the force that opposes the relative motion or tendency of such motion of two surfaces in contact?"
        ),
        QuestionModel(
            trueAnswer: 2,
            answer1: "Zeroth Law of Thermodynamics",
            answer2: "First Law of Thermodynamics",
            answer3: "Second Law of Thermodynamics",
            answer4: "Third Law of Thermodynamics",
            QuestionText: "Which law of thermodynamics states that energy cannot be created or destroyed, only converted from one form to another?"
        ),
        QuestionModel(
            trueAnswer: 4,
            answer1: "Watt",
            answer2: "Volt",
            answer3: "Hertz",
            answer4: "Hertz",
            QuestionText: "What is the SI unit of frequency?"
        ),
        QuestionModel(
            trueAnswer: 3,
            answer1: "Newton's First Law",
            answer2: "Newton's Second Law",
            answer3: "Newton's Third Law",
            answer4: "Newton's Law of Universal Gravitation",
            QuestionText: "Which law of motion states that for every action, there is an equal and opposite reaction?"
        ),
      ],
      color: Colors.teal),
  SubjectModel(
      resultKey: 'programming-result',
      subjectName: "Programming",
      iconPath: "assets/images/programming.png",
      questions: [
        QuestionModel(
            trueAnswer: 4,
            answer1: "Function",
            answer2: "Loop",
            answer3: "Variable",
            answer4: "Variable",
            QuestionText: "What is the term for a named storage location in a program where data can be stored?"
        ),
        QuestionModel(
            trueAnswer: 3,
            answer1: "func",
            answer2: "def",
            answer3: "def",
            answer4: "function",
            QuestionText: "In Python, which keyword is used to define a function?"
        ),
        QuestionModel(
            trueAnswer: 2,
            answer1: "Compiled",
            answer2: "Interpreted",
            answer3: "Low-level",
            answer4: "Static",
            QuestionText: "What type of programming language is JavaScript?"
        ),
        QuestionModel(
            trueAnswer: 1,
            answer1: "Repeating a set of instructions",
            answer2: "Declaring variables",
            answer3: "Performing calculations",
            answer4: "Displaying output",
            QuestionText: "What is the primary purpose of a loop in programming?"
        ),
        QuestionModel(
            trueAnswer: 4,
            answer1: "Integer",
            answer2: "Float",
            answer3: "Boolean",
            answer4: "String",
            QuestionText: "Which data type in Python is used to store a sequence of characters?"
        ),
        QuestionModel(
            trueAnswer: 3,
            answer1: "HyperText Markup Language",
            answer2: "Highly Typed Multilanguage",
            answer3: "HyperText Markup Language",
            answer4: "Hyper Transfer Markup Language",
            QuestionText: "What does HTML stand for in web development?"
        ),
        QuestionModel(
            trueAnswer: 1,
            answer1: "Cascading Style Sheets",
            answer2: "Computer Style Syntax",
            answer3: "Creative Style Source",
            answer4: "Coded Style System",
            QuestionText: "What does CSS stand for in web development?"
        ),
        QuestionModel(
            trueAnswer: 2,
            answer1: "A type of data",
            answer2: "An error in the code structure",
            answer3: "A logical error",
            answer4: "A runtime error",
            QuestionText: "In programming, what is a syntax error?"
        ),
        QuestionModel(
            trueAnswer: 4,
            answer1: "Python",
            answer2: "JavaScript",
            answer3: "Ruby",
            answer4: "Swift",
            QuestionText: "Which programming language is often used for developing mobile apps for iOS devices?"
        ),
        QuestionModel(
            trueAnswer: 1,
            answer1: "Function",
            answer2: "Variable",
            answer3: "Method",
            answer4: "Loop",
            QuestionText: "What is the term for a named block of code that performs a specific task in a program?"
        ),
        QuestionModel(
            trueAnswer: 3,
            answer1: "A function",
            answer2: "A variable",
            answer3: "An instance of a class",
            answer4: "A loop",
            QuestionText: "In object-oriented programming, what is an 'object'?"
        ),
        QuestionModel(
            trueAnswer: 2,
            answer1: "Running tests on code",
            answer2: "Tracking changes in code and collaborating with others",
            answer3: "Writing code documentation",
            answer4: "Optimizing code for performance",
            QuestionText: "What is the main purpose of version control systems like Git?"
        ),
        QuestionModel(
            trueAnswer: 1,
            answer1: "Python",
            answer2: "Java",
            answer3: "C++",
            answer4: "PHP",
            QuestionText: "Which programming language is often used for data analysis and scientific computing?"
        ),
        QuestionModel(
            trueAnswer: 4,
            answer1: "Advanced Programming Interface",
            answer2: "Application Program Interface",
            answer3: "Automated Protocol Integration",
            answer4: "Application Programming Interface",
            QuestionText: "What does API stand for in the context of web development?"
        ),
        QuestionModel(
            trueAnswer: 2,
            answer1: "Imperative",
            answer2: "Functional",
            answer3: "Object-Oriented",
            answer4: "Procedural",
            QuestionText: "Which programming paradigm encourages thinking of problems as a series of transformations on data?"
        ),

      ],
      color: Colors.teal),
];


}